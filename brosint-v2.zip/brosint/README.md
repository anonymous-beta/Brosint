# BROsint 2.0

A standalone OSINT recon framework with two interfaces on one Python backend:

- **Terminal TUI** — full recon console, no browser required.
- **Web graph UI** — optional, runs on `localhost` only, renders findings as
  a node graph you can click through.

No third-party SaaS, no bundled API keys. Every module either talks directly
to a public protocol (WHOIS, DNS) or a free public endpoint, and reads
optional keys only from your own environment variables — never hardcoded,
never phoned home anywhere else.

## Architecture

```
core/           engine, data models, config, module base class
modules/        one file per OSINT module (domain, email, username, ip, file)
correlator/     turns scan results into a node/edge graph
tui/            Textual terminal interface
webapp/
  backend/      FastAPI REST API
  frontend/     single-page node-graph UI (vis-network)
brosint.py      CLI entry point for all three modes
```

Every module is a small, isolated class (see `core/module_base.py`). If one
module throws an exception, the engine catches it, logs it to
`ScanResult.errors`, and every other module keeps running — a bad or
rate-limited lookup can't take down a scan.

## Setup

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## Usage

```bash
# Terminal UI
python brosint.py --tui

# Web UI (open http://127.0.0.1:8000)
python brosint.py --web

# One-off CLI scan, prints JSON
python brosint.py --domain example.com
python brosint.py --email someone@example.com
python brosint.py --username someuser
python brosint.py --ip 8.8.8.8
```

## Included modules

| Module | Target type | Data source |
|---|---|---|
| `domain_recon` | domain | WHOIS + DNS (A/AAAA/MX/TXT/NS/CNAME) |
| `email_analysis` | email | Format validation + MX lookup |
| `username_enum` | username | Public profile URL checks across common platforms |
| `ip_geolocation` | ip | ip-api.com free endpoint |
| `file_metadata` | file (local path) | EXIF/metadata extraction |

## Adding a module

1. Create `modules/your_module.py`, subclass `BaseModule` from
   `core/module_base.py`.
2. Implement `async def run(self, target) -> list[Finding]`.
3. Register it in `modules/__init__.py`.

If your module needs an API key you own (e.g. a breach-database or paid
threat-intel provider), set `requires_key = "YOUR_ENV_VAR_NAME"` on the
class and read it via `settings.get_secret(...)` — the module will
automatically report itself unavailable until the key is set in the
environment, so the framework stays standalone by default.

## Scope and intentional omissions

This framework only queries data sources that are public and don't require
bypassing authentication, paying for access without your own credentials,
or scraping private platforms. It intentionally does not include mailbox
existence probing (SMTP verification), automated social-media scraping
behind login walls, or breach-database aggregation without your own paid
API key. Extend it with those only against targets you're authorized to
investigate, and check your local laws — stalking and unauthorized
surveillance statutes apply to OSINT tooling like any other technique.

## License

MIT — use responsibly, for research and authorized investigations only.
